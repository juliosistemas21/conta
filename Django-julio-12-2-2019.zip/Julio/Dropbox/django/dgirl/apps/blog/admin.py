#SITIO DEL TUTORIAL
#https://djangotutorial.readthedocs.io/es/1.8/intro/tutorial02.html
from django.contrib import admin
from .models import Post,Comment

admin.site.register(Post)
admin.site.register(Comment)
