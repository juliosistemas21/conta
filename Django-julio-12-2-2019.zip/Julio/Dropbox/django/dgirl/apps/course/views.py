from django.shortcuts import render
from .models import Student,Subject
from django.views.generic.edit import CreateView
from .forms import StudentForm

def list_student(request):
	student=Student.objects.all()
	return render(request,template_name='list_student.html',context={'student':student})


def list_cursos(request):
	cursos=Subject.objects.all()
	return render(request,template_name='list_cursos.html',context={'cursos':cursos})

def index(request):
	return render(request,template_name='index.html')

class StudentCreate(CreateView):
	model=Student
	from_class=StudentForm
	template_name='add_student.html'
	
	def get_success_url(self):
		return reverse('course:list_student')
