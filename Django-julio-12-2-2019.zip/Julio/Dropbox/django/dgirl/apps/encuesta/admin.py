from django.contrib import admin
from .models import Preguntas,Eleccion

class PreguntasAdmin(admin.ModelAdmin):
	fieldsets=[
	('La pregunta?',	{'fields':['pregunta_texto']}),
	('Informacion del dia',	{'fields':['dia_publicacion'],'classes':['collapse']}),

	]
#	fields=['dia_publicacion','pregunta_texto']


admin.site.register(Preguntas,PreguntasAdmin)
admin.site.register(Eleccion)
