#Hallar la progresion aritmetica
import os
a1=0
an=0
n=0
d=0
Term=[]
Temp=[0]

S=(a1+an)*n/2
an=a1+(n-1)*d

#n=input()
os.system("cls")
print("IMPRIMIR LA PROGRESION ARITMÉTICA")
print("Ingrese el numero de terminos: ")
n=int(input())

for i in range(n):
	print("Ingrese el termino numero",i+1)
	x=input()
	Term.append(x)

def sumaTotal():
	print("Ingresaste a la suma total")

def numeroCentral():
	print("Ingresaste al Numero central")

def diferencia():
	print("Ingresaste a la diferencia")

def TerminoX():
	print("Ingresaste a termino en X")

def menu(opcion):
	item={
	0:'1--> Calcular Suma total',
	1:'2-->Numero central',
	2:'3-->Diferencia',
	3:'4-->Termino en posición X',
	4:"5-->SALIR"
	}
	return item.get(opcion,"No es una opción")


def seleccionMenu():
	os.system("cls")
	print("<------------------------------------------>")
	print("  ",Term)
	print("<------------------------------------------>")
	print("    ")
	print("QUE NECESITA RESOLVER: ")
	print("    ")
	for i in range(5):
		print(menu(i))


seleccionMenu()
x=int(input())

if x==1:
	sumaTotal()
elif x==2:
	numeroCentral()
elif x==3:
	diferencia()
elif x==4:
	TerminoX()
else:
	print("Saliste simplemente")
