from django.apps import AppConfig


class MiblogConfig(AppConfig):
    name = 'MiBlog'
