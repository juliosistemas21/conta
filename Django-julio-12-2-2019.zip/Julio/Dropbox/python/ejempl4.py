import tkinter

tkinter._test()
# from operator import length_hint

# test_list=[1,2,3,4,5]
# print("the list is : "+str(test_list))
# counter=0
# for i in test_list:
# 	counter=counter+1
# print("Length of list using naive method is: " + str(counter))

# a=[]
# a.append("Hello")
# a.append("Geeks")
# a.append("For")
# a.append("Geeks")

# print("The Length of list is:",len(a))

# n=len([10,20,30,50])
# print("The Length of list is: ",n)


# print("------------------------------------")

# test_list2=[1,4,5,7,8,9]
# print("The list is:"+str(test_list2))

# list_len=len(test_list2)
# list_len_hint=length_hint(test_list2)

# print("Length of list using len() is: "+str(list_len))
# print("Length of list using length_hint() is: "+str(list_len_hint))