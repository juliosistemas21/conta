#excercise 3

start =11
end=25

for val in range(start,end+1):
    if val>1:
        for n in range(2,val):
            if (val%n)==0:
                break
            else:
                print(val)

#excercise 2

##def CirucloArea(r):
##    PI=3.142
##    return PI*(r*r)
##
##print("The Area is ")
##print (CirucloArea(5))



#excercise 1

##def compound_interest(principle,rate,time):
##    CI = principle * (pow((1+rate/100),time))
##    print("Compound interest is ", CI)
##compound_interest(8000,8.5,12)