# def cambiainifin(arr,n):
# 	temp=[1]
# 	temp[0]=arr[0]

# 	arr[0]=arr[n-1]
# 	arr[n-1]=temp[0]
# 	return arr

# arr=['1','2','3','4']
# n=len(arr)
# print(arr)
# print(cambiainifin(arr,n))


# def swapList(newlist):
# 	newlist[0],newlist[-1]=newlist[-1],newlist[0]
# 	return newlist

# newlist=['1','2','3','4']
# print(newlist)
# print(swapList(newlist))

#funcion propia
# def printbucle(n,l):
# 	for i in range(l):
# 		print("Posición: ",(i), " es ", n[i])
		
		

# a=['j','u','l','i','o']
# longitud=len(a)
# printbucle(a,longitud)
# print("La longitud de la cadena es: ",longitud)


# def construct(n, m, a): 
#     ind = 0
  
#     # Finding the index which is not -1 
#     for i in range(n): 
#         if (a[i]!=-1): 
#             ind = i 
#             break
  
#     # Calculating the values of the indexes ind-1 to 0 
#     for i in range(ind-1, -1, -1): 
#         if (a[i]==-1): 
#             a[i]=(a[i + 1]-1 + m)% m 
  
#     # Calculating the values of the indexes ind + 1 to n 
#     for i in range(ind + 1, n): 
#         if(a[i]==-1): 
#             a[i]=(a[i-1]+1)% m 
#     print(*a) 
  
# # Driver code 
# n, m = 6, 7
# a =[5, -1, -1, 1, 2, 3] 
# construct(n, m, a) 



# def leftRotate(arr,d,n):
# 	for i in range(d):
# 		leftRotateByOne(arr,n)

# def leftRotateByOne(arr,n):
# 	temp=arr[0]
# 	for i in range(n-1):
# 		arr[i]=arr[i+1]
# 	arr[n-1]=temp


# def printArray(arr,size):
# 	for i in range(size):
# 		print("%d"%arr[i],end=" ")


# arr=[1,2,3,4,5,6,7]
# leftRotate(arr,6,7)
# printArray(arr,7)


# def RotateArray(arr,n):
# 	NewArray=[n]
# 	for i in range(1,n):
# 		NewArray[i]+=arr[n-1]
# 	return NewArray

# arr=[]
# arr=[45,44,43,42]
# n=len(arr)
# Respuesta=RotateArray(arr,n)
# print(Respuesta)






#NUMERO mayor y menor de un Array
# def largest(arr,n):
# 	max=arr[0]
# 	min=arr[0]

# 	for i in range(1,n):
# 		if arr[i]>max:
# 			max=arr[i]
# 		if arr[i]<min:
# 			min=arr[i]
# 	return max,min

# arr =[10,324,45,90,9899,1,45555]
# n=len(arr)
# Ans=largest(arr,n)


# print("Largest in given array is:", Ans[0], "and the minimal is:",Ans[1])

#ARRAYS , SUMA DE LOS ITEMS DE UN ARRAY

# def _sum(arr):
# 	return(sum(arr))

# arr=[]
# arr=[12,3,4,15]
# n=len(arr)
# ans=_sum(arr)

# print("Sum of the array is", ans)


#NUMEROS PRIMOS
# num =7
# if num>1:
# 	for i in range(2,num//2):
# 		if(num%i)==0:
# 			print(num,"is not a prime number")
# 			break
# 		else:
# 			print(num,"is a prime number")
# 			break
# else:
# 	print(num,"is not a prime number")

#CODIGO ASCII
# c='m'
# print("The ASCII value of '"+c+"'is ",ord(c))


#SUMA DE NUMEROS AL CUADRADO

# def squaresum(n):
# 	sm=0
# 	for i in range(1,n+1):
# 		sm=sm+(i*i)
# 	return sm

# def squaresum2(n):
# 	return(n*(n+1)*(2*n+1))//6


# n=4
# m=4
# print(squaresum(n))
# print(squaresum2(m))



