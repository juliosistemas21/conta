num1=input("First number: ")
num2=input("Second number: ")

sum=float(num1)+float(num2)

print("sum of {} and {} is {}".format(num1,num2,sum))