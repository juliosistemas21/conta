from tkinter import *
root=Tk()
root.mainloop()